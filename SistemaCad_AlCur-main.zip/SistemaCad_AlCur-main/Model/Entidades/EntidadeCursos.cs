﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Entidades
{
    class EntidadeCursos
    {
        public int ID_CURSO { get; set; }
        public string NOME_CUR { get; set; }
        public string SIGLA { get; set; }
    }
}
