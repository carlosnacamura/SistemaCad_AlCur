﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CadAlunCurs.DAOB;

namespace CadAlunCurs.Formulários.Cadastrar
{
    public partial class FrmCadastroAluno : Form
    {
        //private string LinhaConexao = "Server=LS05MPF;Database=AULA_DS;User Id=sa;Password=admsasql;";
        private string LinhaConexao = "Server=CLAUDIA1968\\DBCARLOS;Database=SistemAlunCurs;User=carkapo;Password=112233;";
        private SqlConnection Conexao;
        DAOCursos cursoDao = new DAOCursos();
        public FrmCadastroAluno()
        {
            InitializeComponent();

            cbCursos.DataSource = cursoDao.PreencherComboBox();
            cbCursos.DisplayMember = "NOME_CUR";
            cbCursos.ValueMember = "ID_CURSO";
        }
        private void btnCadastro_Click(object sender, EventArgs e)
        {
            string query = "insert into ALUNOS (NOME, IDADE, EMAIL,ID_CURSO) Values (@nome, @idade, @email,@idCurso)";

            Conexao = new SqlConnection(LinhaConexao);
            Conexao.Open();

            SqlCommand comando = new SqlCommand(query, Conexao);

            comando.Parameters.Add(new SqlParameter("@nome", txtNome.Text));
            comando.Parameters.Add(new SqlParameter("@idade", numIdade.Text));
            comando.Parameters.Add(new SqlParameter("@email", txtEmail.Text));
            comando.Parameters.Add(new SqlParameter("@idCurso", Convert.ToInt32(cbCursos.SelectedValue)));


            int resposta = comando.ExecuteNonQuery();

            if (resposta == 1)
            {
                MessageBox.Show("Aluno cadastrado com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Erro ao Cadastrar", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmCadastroAluno_Load(object sender, EventArgs e)
        {

        }

        
    }
}
