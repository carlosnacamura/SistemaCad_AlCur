﻿using System;
using System.Windows.Forms;

namespace CadAlunCurs.Formulários
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void btnCurso_Click(object sender, EventArgs e)
        {
            Curso c = new Curso();
            c.ShowDialog();
        }

        private void btnAlunos_Click(object sender, EventArgs e)
        {
            Aluno a = new Aluno();
            a.ShowDialog();
        }
    }
}
